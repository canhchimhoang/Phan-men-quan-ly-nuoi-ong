import 'package:flutter/material.dart';

import '../db/app_database.dart';
import '../models/models.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// Danh mục "Vị trí của tổ ong" (nhập riêng, dùng để chọn khi tạo tổ ong).
class LocationsScreen extends StatefulWidget {
  const LocationsScreen({super.key});

  @override
  State<LocationsScreen> createState() => _LocationsScreenState();
}

/// Hộp thoại thêm/sửa vị trí; trả về id (hoặc null nếu hủy).
/// Dùng chung với form tổ ong (nút "thêm vị trí mới").
Future<int?> showLocationDialog(BuildContext context, {HiveLocation? edit}) {
  final ctl = TextEditingController(text: edit?.name ?? '');
  final key = GlobalKey<FormState>();
  return showDialog<int>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(edit == null ? 'Thêm vị trí' : 'Sửa vị trí'),
      content: Form(
        key: key,
        child: TextFormField(
          controller: ctl,
          autofocus: true,
          minLines: 2,
          maxLines: 4,
          decoration: const InputDecoration(
            labelText: 'Vị trí của tổ ong',
            hintText: 'VD: Khu A; Vườn Phi; xã Thạch Mỹ; TP. Đà Nẵng',
          ),
          validator: (v) =>
              (v == null || v.trim().isEmpty) ? 'Vui lòng nhập vị trí' : null,
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(c), child: const Text('Hủy')),
        FilledButton(
          style: FilledButton.styleFrom(minimumSize: const Size(90, 44)),
          onPressed: () async {
            if (!key.currentState!.validate()) return;
            try {
              final db = AppDatabase.instance;
              int id;
              if (edit == null) {
                id = await db.insertLocation(ctl.text);
              } else {
                await db.updateLocation(edit.id!, ctl.text);
                id = edit.id!;
              }
              if (c.mounted) Navigator.pop(c, id);
            } catch (_) {
              if (c.mounted) showSnack(c, 'Vị trí này đã tồn tại.', error: true);
            }
          },
          child: const Text('Lưu'),
        ),
      ],
    ),
  );
}

class _LocationsScreenState extends State<LocationsScreen> {
  List<HiveLocation> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await AppDatabase.instance.locations();
    if (mounted) {
      setState(() {
        _items = l;
        _loading = false;
      });
    }
  }

  Future<void> _delete(HiveLocation l) async {
    final extra = l.hiveCount > 0
        ? '\n\n${l.hiveCount} tổ ong đang ở vị trí này sẽ chuyển về "chưa có vị trí".'
        : '';
    if (!await confirmDialog(context, 'Xóa vị trí "${l.name}"?$extra')) return;
    await AppDatabase.instance.deleteLocation(l.id!);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Vị trí của tổ ong')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          if (await showLocationDialog(context) != null) _load();
        },
        icon: const Icon(Icons.add_location_alt),
        label: const Text('Thêm vị trí'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const EmptyState(
                  icon: Icons.place_outlined,
                  text: 'Chưa có vị trí nào.\nBấm "Thêm vị trí" để nhập.')
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
                  itemCount: _items.length,
                  itemBuilder: (_, i) {
                    final l = _items[i];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: ListTile(
                        leading: const CircleAvatar(
                          backgroundColor: Color(0x3343A047),
                          child: Icon(Icons.place, color: AppColors.leaf),
                        ),
                        title: Text(l.name,
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text('${l.hiveCount} tổ ong'),
                        trailing: PopupMenuButton<String>(
                          onSelected: (v) async {
                            if (v == 'edit') {
                              if (await showLocationDialog(context, edit: l) !=
                                  null) {
                                _load();
                              }
                            } else {
                              _delete(l);
                            }
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(value: 'edit', child: Text('Sửa')),
                            PopupMenuItem(value: 'delete', child: Text('Xóa')),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
