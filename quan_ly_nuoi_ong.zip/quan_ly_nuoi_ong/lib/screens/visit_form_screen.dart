import 'package:flutter/material.dart';

import '../db/app_database.dart';
import '../models/models.dart';
import '../widgets/common.dart';

/// Form thêm / sửa một lần thăm tổ ong. Trả về true nếu đã lưu.
class VisitFormScreen extends StatefulWidget {
  final Visit? visit;
  final int? initialHiveId;
  const VisitFormScreen({super.key, this.visit, this.initialHiveId});

  @override
  State<VisitFormScreen> createState() => _VisitFormScreenState();
}

class _VisitFormScreenState extends State<VisitFormScreen> {
  static const _defaultConditions = [
    'Đàn ong phát triển tốt',
    'Đàn ong phát triển hơi kém',
    'Đàn ong yếu',
    'Mất ong Chúa',
  ];
  static const _splitOptions = ['chưa', 'đã tách'];

  final _formKey = GlobalKey<FormState>();
  final _no = TextEditingController();
  final _condition = TextEditingController();
  final _honey = TextEditingController(text: '0');
  final _pollen = TextEditingController(text: '0');
  final _propolis = TextEditingController(text: '0');

  List<Hive> _hives = [];
  List<String> _conditions = _defaultConditions;
  Hive? _hive;
  DateTime _date = dateOnly(DateTime.now());
  String _split = 'chưa';
  String? _hiveError;
  bool _busy = false;

  bool get _isEdit => widget.visit != null;

  @override
  void initState() {
    super.initState();
    final v = widget.visit;
    if (v != null) {
      _no.text = '${v.visitNo}';
      _condition.text = v.condition;
      _honey.text = fmtNum(v.honey);
      _pollen.text = fmtNum(v.pollen);
      _propolis.text = fmtNum(v.propolis);
      _date = dateOnly(v.visitDate);
      _split = v.splitStatus.isEmpty ? 'chưa' : v.splitStatus;
    }
    _load();
  }

  @override
  void dispose() {
    for (final c in [_no, _condition, _honey, _pollen, _propolis]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    final db = AppDatabase.instance;
    final hives = await db.hives();
    final used = await db.distinctConditions();
    final all = <String>[..._defaultConditions];
    for (final c in used) {
      if (!all.contains(c)) all.add(c);
    }
    Hive? sel;
    final wantId = widget.visit?.hiveId ?? widget.initialHiveId;
    for (final h in hives) {
      if (h.id == wantId) sel = h;
    }
    if (!mounted) return;
    setState(() {
      _hives = hives;
      _conditions = all;
      _hive = sel;
    });
    if (!_isEdit && sel != null) _suggestNo(sel);
  }

  Future<void> _suggestNo(Hive h) async {
    final n = await AppDatabase.instance.nextVisitNo(h.id!);
    if (mounted) setState(() => _no.text = '$n');
  }

  double _parse(String s) => double.tryParse(s.trim().replaceAll(',', '.')) ?? 0;

  String? _qtyValidator(String? v) {
    final t = (v ?? '').trim().replaceAll(',', '.');
    if (t.isEmpty) return 'Nhập số lượng (0 nếu không có)';
    final d = double.tryParse(t);
    if (d == null || d < 0) return 'Số lượng không hợp lệ';
    return null;
  }

  Future<void> _save() async {
    setState(() => _hiveError = _hive == null ? 'Vui lòng chọn tổ ong' : null);
    if (!_formKey.currentState!.validate() || _hive == null) return;
    setState(() => _busy = true);
    try {
      final db = AppDatabase.instance;
      final no = int.parse(_no.text.trim());
      if (await db.visitNoTaken(_hive!.id!, no, widget.visit?.id)) {
        if (mounted) {
          showSnack(context, '"${_hive!.name}" đã có lần thăm thứ $no.', error: true);
        }
        return;
      }
      final v = Visit(
        id: widget.visit?.id,
        hiveId: _hive!.id!,
        visitNo: no,
        visitDate: _date,
        condition: _condition.text,
        honey: _parse(_honey.text),
        pollen: _parse(_pollen.text),
        propolis: _parse(_propolis.text),
        splitStatus: _split,
      );
      if (_isEdit) {
        await db.updateVisit(v);
      } else {
        await db.insertVisit(v);
      }
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) showSnack(context, 'Không lưu được: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _qty(TextEditingController c, String label, IconData icon) => TextFormField(
        controller: c,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon)),
        validator: _qtyValidator,
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? 'Sửa lần thăm' : 'Ghi nhận lần thăm')),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              PickerField<Hive>(
                label: 'Tên tổ ong',
                value: _hive,
                items: _hives,
                itemLabel: (h) => h.name,
                errorText: _hiveError,
                icon: Icons.hive,
                onChanged: (h) {
                  setState(() {
                    _hive = h;
                    _hiveError = null;
                  });
                  if (h != null && !_isEdit) _suggestNo(h);
                },
              ),
              const SizedBox(height: 14),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _no,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Lần thăm thứ'),
                      validator: (v) {
                        final n = int.tryParse((v ?? '').trim());
                        return (n == null || n < 1) ? 'Nhập số ≥ 1' : null;
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: DateField(
                      label: 'Ngày thăm',
                      value: _date,
                      onChanged: (d) => setState(() => _date = d ?? _date),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _condition,
                minLines: 2,
                maxLines: 4,
                textCapitalization: TextCapitalization.sentences,
                decoration: const InputDecoration(
                  labelText: 'Tình trạng của tổ ong',
                  alignLabelWithHint: true,
                ),
                validator: (v) => (v == null || v.trim().isEmpty)
                    ? 'Vui lòng nhập tình trạng'
                    : null,
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  for (final c in _conditions)
                    ActionChip(
                      label: Text(c, style: const TextStyle(fontSize: 12.5)),
                      onPressed: () => setState(() => _condition.text = c),
                    ),
                ],
              ),
              const SizedBox(height: 16),
              _qty(_honey, 'Số lượng mật lấy được (gram)', Icons.water_drop),
              const SizedBox(height: 14),
              _qty(_pollen, 'Số lượng phấn hoa lấy được (gram)', Icons.local_florist),
              const SizedBox(height: 14),
              _qty(_propolis, 'Số lượng keo lấy được (gram)', Icons.bubble_chart),
              const SizedBox(height: 16),
              const Text('Tình trạng tách đàn',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              SegmentedButton<String>(
                segments: [
                  for (final s in _splitOptions)
                    ButtonSegment(value: s, label: Text(s)),
                ],
                selected: {_split},
                onSelectionChanged: (s) => setState(() => _split = s.first),
              ),
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: _busy ? null : _save,
                icon: const Icon(Icons.save),
                label: const Text('LƯU'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
