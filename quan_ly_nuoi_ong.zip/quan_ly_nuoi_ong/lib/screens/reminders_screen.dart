import 'package:flutter/material.dart';

import '../db/app_database.dart';
import '../models/models.dart';
import '../services/notification_service.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// Lịch nhắc thăm tổ ong: đặt ngày giờ, ứng dụng sẽ gửi thông báo đúng giờ.
class RemindersScreen extends StatefulWidget {
  const RemindersScreen({super.key});

  @override
  State<RemindersScreen> createState() => _RemindersScreenState();
}

class _RemindersScreenState extends State<RemindersScreen> {
  List<Reminder> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    NotificationService.requestPermissions();
    _load();
  }

  Future<void> _load() async {
    final l = await AppDatabase.instance.reminders();
    if (mounted) {
      setState(() {
        _items = l;
        _loading = false;
      });
    }
  }

  Future<void> _openForm([Reminder? r]) async {
    final saved = await Navigator.of(context).push<bool>(
        MaterialPageRoute(builder: (_) => ReminderFormScreen(reminder: r)));
    if (saved == true) _load();
  }

  Future<void> _toggleDone(Reminder r, bool done) async {
    final db = AppDatabase.instance;
    await db.updateReminder(Reminder(
      id: r.id,
      hiveId: r.hiveId,
      remindAt: r.remindAt,
      note: r.note,
      done: done,
    ));
    if (done) {
      await NotificationService.cancel(r.id!);
    } else {
      await NotificationService.schedule(
        id: r.id!,
        title: 'Đến giờ thăm ${r.hiveName}',
        body: r.note.isEmpty ? 'Bạn có lịch thăm tổ ong hôm nay.' : r.note,
        when: r.remindAt,
      );
    }
    _load();
  }

  Future<void> _delete(Reminder r) async {
    if (!await confirmDialog(context,
        'Xóa lịch nhắc thăm "${r.hiveName}" lúc ${fmtDateTime(r.remindAt)}?')) {
      return;
    }
    await NotificationService.cancel(r.id!);
    await AppDatabase.instance.deleteReminder(r.id!);
    _load();
  }

  Future<void> _test() async {
    final ok = await NotificationService.requestPermissions();
    if (!ok) {
      if (mounted) {
        showSnack(
            context,
            'Chưa được cấp quyền thông báo. Hãy bật trong Cài đặt > Ứng dụng > Quản lý nuôi ong.',
            error: true);
      }
      return;
    }
    await NotificationService.showTest();
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Nhắc lịch thăm'),
        actions: [
          IconButton(
            tooltip: 'Gửi thử thông báo',
            icon: const Icon(Icons.notifications_active_outlined),
            onPressed: _test,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openForm(),
        icon: const Icon(Icons.add_alarm),
        label: const Text('Thêm lịch nhắc'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const EmptyState(
                  icon: Icons.notifications_none,
                  text: 'Chưa có lịch nhắc nào.\nBấm "Thêm lịch nhắc" để đặt giờ thăm tổ ong.')
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
                  itemCount: _items.length,
                  itemBuilder: (_, i) {
                    final r = _items[i];
                    final overdue = !r.done && r.remindAt.isBefore(now);
                    return Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: ListTile(
                        onTap: () => _openForm(r),
                        leading: Checkbox(
                          value: r.done,
                          onChanged: (v) => _toggleDone(r, v ?? false),
                        ),
                        title: Text(r.hiveName,
                            style: TextStyle(
                                fontWeight: FontWeight.w800,
                                decoration:
                                    r.done ? TextDecoration.lineThrough : null)),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(children: [
                              const Icon(Icons.alarm, size: 15),
                              const SizedBox(width: 4),
                              Text(fmtDateTime(r.remindAt)),
                              if (overdue) ...[
                                const SizedBox(width: 8),
                                Text('Quá hạn',
                                    style: TextStyle(
                                        color: Colors.red.shade700,
                                        fontWeight: FontWeight.w700)),
                              ],
                              if (r.done) ...[
                                const SizedBox(width: 8),
                                const Text('Đã thăm',
                                    style: TextStyle(
                                        color: AppColors.leaf,
                                        fontWeight: FontWeight.w700)),
                              ],
                            ]),
                            if (r.note.isNotEmpty) Text(r.note),
                          ],
                        ),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => _delete(r),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}

class ReminderFormScreen extends StatefulWidget {
  final Reminder? reminder;
  const ReminderFormScreen({super.key, this.reminder});

  @override
  State<ReminderFormScreen> createState() => _ReminderFormScreenState();
}

class _ReminderFormScreenState extends State<ReminderFormScreen> {
  final _note = TextEditingController();
  List<Hive> _hives = [];
  Hive? _hive;
  late DateTime _date;
  late TimeOfDay _time;
  String? _hiveError;
  bool _busy = false;

  bool get _isEdit => widget.reminder != null;

  @override
  void initState() {
    super.initState();
    final r = widget.reminder;
    if (r != null) {
      _date = dateOnly(r.remindAt);
      _time = TimeOfDay(hour: r.remindAt.hour, minute: r.remindAt.minute);
      _note.text = r.note;
    } else {
      final t = DateTime.now().add(const Duration(days: 1));
      _date = dateOnly(t);
      _time = const TimeOfDay(hour: 7, minute: 0);
    }
    _load();
  }

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final hives = await AppDatabase.instance.hives();
    Hive? sel;
    for (final h in hives) {
      if (h.id == widget.reminder?.hiveId) sel = h;
    }
    if (mounted) {
      setState(() {
        _hives = hives;
        _hive = sel;
      });
    }
  }

  DateTime get _when =>
      DateTime(_date.year, _date.month, _date.day, _time.hour, _time.minute);

  Future<void> _pickTime() async {
    final t = await showTimePicker(
      context: context,
      initialTime: _time,
      helpText: 'Chọn giờ nhắc',
      cancelText: 'Hủy',
      confirmText: 'Chọn',
    );
    if (t != null) setState(() => _time = t);
  }

  Future<void> _save() async {
    if (_hive == null) {
      setState(() => _hiveError = 'Vui lòng chọn tổ ong');
      return;
    }
    setState(() => _busy = true);
    try {
      final db = AppDatabase.instance;
      final old = widget.reminder;
      final r = Reminder(
        id: old?.id,
        hiveId: _hive!.id!,
        remindAt: _when,
        note: _note.text,
        done: false,
      );
      int id;
      if (old == null) {
        id = await db.insertReminder(r);
      } else {
        await db.updateReminder(r);
        id = old.id!;
        await NotificationService.cancel(id);
      }
      final granted = await NotificationService.requestPermissions();
      await NotificationService.schedule(
        id: id,
        title: 'Đến giờ thăm ${_hive!.name}',
        body: _note.text.trim().isEmpty
            ? 'Bạn có lịch thăm tổ ong hôm nay.'
            : _note.text.trim(),
        when: r.remindAt,
      );
      if (!mounted) return;
      if (!granted) {
        showSnack(
            context,
            'Đã lưu lịch nhưng chưa có quyền thông báo — hãy bật trong Cài đặt.',
            error: true);
      }
      Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) showSnack(context, 'Không lưu được: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final past = !_when.isAfter(DateTime.now());
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? 'Sửa lịch nhắc' : 'Thêm lịch nhắc')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            PickerField<Hive>(
              label: 'Tổ ong cần thăm',
              value: _hive,
              items: _hives,
              itemLabel: (h) => h.name,
              errorText: _hiveError,
              icon: Icons.hive,
              onChanged: (h) => setState(() {
                _hive = h;
                _hiveError = null;
              }),
            ),
            const SizedBox(height: 14),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 3,
                  child: DateField(
                    label: 'Ngày nhắc',
                    value: _date,
                    onChanged: (d) => setState(() => _date = d ?? _date),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: _pickTime,
                    child: InputDecorator(
                      decoration: const InputDecoration(
                        labelText: 'Giờ nhắc',
                        suffixIcon: Icon(Icons.access_time),
                      ),
                      child: Text(
                        '${_time.hour.toString().padLeft(2, '0')}:${_time.minute.toString().padLeft(2, '0')}',
                        style: const TextStyle(fontSize: 16),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            if (past)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text('Thời điểm này đã qua nên sẽ không có thông báo.',
                    style: TextStyle(color: Colors.red.shade700)),
              ),
            const SizedBox(height: 14),
            TextField(
              controller: _note,
              minLines: 2,
              maxLines: 4,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(
                labelText: 'Ghi chú (không bắt buộc)',
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _busy ? null : _save,
              icon: const Icon(Icons.alarm_add),
              label: const Text('LƯU LỊCH NHẮC'),
            ),
          ],
        ),
      ),
    );
  }
}
