import 'package:flutter/material.dart';

import '../db/app_database.dart';
import '../services/session.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'hives_screen.dart';
import 'locations_screen.dart';
import 'login_screen.dart';
import 'reminders_screen.dart';
import 'search_screen.dart';
import 'stats_screen.dart';
import 'visits_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String, double> _ov = const {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final o = await AppDatabase.instance.overview();
    if (mounted) setState(() => _ov = o);
  }

  Future<void> _open(Widget page) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
    _load();
  }

  Future<void> _logout() async {
    if (!await confirmDialog(context, 'Bạn muốn đăng xuất?',
        title: 'Đăng xuất', okText: 'Đăng xuất')) {
      return;
    }
    await Session.signOut();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const LoginScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final user = Session.current;
    final menu = <_MenuItem>[
      _MenuItem('Quản lý tổ ong', Icons.hive, const Color(0xFFF9A825),
          () => _open(const HivesScreen())),
      _MenuItem('Thăm tổ ong', Icons.edit_note, const Color(0xFF8D6E63),
          () => _open(const VisitsScreen())),
      _MenuItem('Vị trí tổ ong', Icons.place, const Color(0xFF43A047),
          () => _open(const LocationsScreen())),
      _MenuItem('Tra cứu', Icons.search, const Color(0xFF1E88E5),
          () => _open(const SearchScreen())),
      _MenuItem('Thống kê, báo cáo', Icons.bar_chart, const Color(0xFFE65100),
          () => _open(const StatsScreen())),
      _MenuItem('Nhắc lịch thăm', Icons.notifications_active,
          const Color(0xFF8E24AA), () => _open(const RemindersScreen())),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Quản lý nuôi ong'),
        actions: [
          IconButton(
              tooltip: 'Đăng xuất',
              icon: const Icon(Icons.logout),
              onPressed: _logout),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(
              'Xin chào, ${(user?.fullName.isNotEmpty ?? false) ? user!.fullName : (user?.username ?? '')} 🐝',
              style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: AppColors.brown),
            ),
            const SizedBox(height: 14),
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 1.05,
              children: [
                StatTile(
                    label: 'Tổ ong',
                    value: fmtNum(_ov['hives'] ?? 0),
                    icon: Icons.hive,
                    color: AppColors.honeyTile),
                StatTile(
                    label: 'Lần thăm',
                    value: fmtNum(_ov['visits'] ?? 0),
                    icon: Icons.fact_check,
                    color: AppColors.propolis),
                StatTile(
                    label: 'Lịch sắp tới',
                    value: fmtNum(_ov['pending'] ?? 0),
                    icon: Icons.alarm,
                    color: const Color(0xFF8E24AA)),
                StatTile(
                    label: 'Mật',
                    value: fmtGram(_ov['honey'] ?? 0),
                    icon: Icons.water_drop,
                    color: AppColors.honeyTile),
                StatTile(
                    label: 'Phấn hoa',
                    value: fmtGram(_ov['pollen'] ?? 0),
                    icon: Icons.local_florist,
                    color: const Color(0xFFF9A825)),
                StatTile(
                    label: 'Keo ong',
                    value: fmtGram(_ov['propolis'] ?? 0),
                    icon: Icons.bubble_chart,
                    color: AppColors.propolis),
              ],
            ),
            const SizedBox(height: 20),
            const Text('Chức năng',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.35,
              children: [for (final m in menu) _MenuCard(item: m)],
            ),
          ],
        ),
      ),
    );
  }
}

class _MenuItem {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  _MenuItem(this.title, this.icon, this.color, this.onTap);
}

class _MenuCard extends StatelessWidget {
  final _MenuItem item;
  const _MenuCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      elevation: 1.5,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: item.onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 26,
                backgroundColor: item.color.withAlpha(40),
                child: Icon(item.icon, size: 30, color: item.color),
              ),
              const SizedBox(height: 10),
              Text(item.title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, fontSize: 15)),
            ],
          ),
        ),
      ),
    );
  }
}
