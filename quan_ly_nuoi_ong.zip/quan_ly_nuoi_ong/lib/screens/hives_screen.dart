import 'package:flutter/material.dart';

import '../db/app_database.dart';
import '../models/models.dart';
import '../services/notification_service.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'hive_form_screen.dart';
import 'visit_form_screen.dart';

/// Danh sách tổ ong: thêm / sửa / xóa.
class HivesScreen extends StatefulWidget {
  const HivesScreen({super.key});

  @override
  State<HivesScreen> createState() => _HivesScreenState();
}

class _HivesScreenState extends State<HivesScreen> {
  List<Hive> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await AppDatabase.instance.hives();
    if (mounted) {
      setState(() {
        _items = l;
        _loading = false;
      });
    }
  }

  Future<void> _openForm([Hive? h]) async {
    final saved = await Navigator.of(context).push<bool>(
        MaterialPageRoute(builder: (_) => HiveFormScreen(hive: h)));
    if (saved == true) _load();
  }

  Future<void> _delete(Hive h) async {
    final db = AppDatabase.instance;
    final n = await db.visitCountOfHive(h.id!);
    final extra = n > 0
        ? '\n\nToàn bộ $n lần thăm và lịch nhắc của tổ này cũng sẽ bị xóa.'
        : '';
    if (!await confirmDialog(context, 'Xóa tổ ong "${h.name}"?$extra')) return;
    for (final rid in await db.reminderIdsOfHive(h.id!)) {
      await NotificationService.cancel(rid);
    }
    await db.deleteHive(h.id!);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Quản lý tổ ong')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openForm(),
        icon: const Icon(Icons.add),
        label: const Text('Thêm tổ ong'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const EmptyState(
                  icon: Icons.hive_outlined,
                  text: 'Chưa có tổ ong nào.\nBấm "Thêm tổ ong" để bắt đầu.')
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
                  itemCount: _items.length,
                  itemBuilder: (_, i) => _HiveCard(
                    hive: _items[i],
                    onEdit: () => _openForm(_items[i]),
                    onDelete: () => _delete(_items[i]),
                    onVisit: () async {
                      await Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) =>
                              VisitFormScreen(initialHiveId: _items[i].id)));
                    },
                  ),
                ),
    );
  }
}

class _HiveCard extends StatelessWidget {
  final Hive hive;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onVisit;
  const _HiveCard({
    required this.hive,
    required this.onEdit,
    required this.onDelete,
    required this.onVisit,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onEdit,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 4, 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const CircleAvatar(
                radius: 24,
                backgroundColor: Color(0x33F9A825),
                child: Icon(Icons.hive, color: AppColors.honeyTile),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(hive.name,
                        style: const TextStyle(
                            fontSize: 17, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text('${hive.code}  •  tạo ${fmtDate(hive.createdDate)}',
                        style: const TextStyle(
                            color: Colors.black54, fontSize: 13)),
                    const SizedBox(height: 6),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.place, size: 16, color: AppColors.leaf),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                              hive.locationName.isEmpty
                                  ? 'Chưa có vị trí'
                                  : hive.locationName,
                              style: const TextStyle(fontSize: 13.5)),
                        ),
                      ],
                    ),
                    if (hive.characteristics.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(hive.characteristics,
                          style: const TextStyle(
                              fontSize: 13, color: Colors.black87)),
                    ],
                  ],
                ),
              ),
              PopupMenuButton<String>(
                onSelected: (v) {
                  if (v == 'edit') onEdit();
                  if (v == 'visit') onVisit();
                  if (v == 'delete') onDelete();
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'visit', child: Text('Ghi nhận lần thăm')),
                  PopupMenuItem(value: 'edit', child: Text('Sửa')),
                  PopupMenuItem(value: 'delete', child: Text('Xóa')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
