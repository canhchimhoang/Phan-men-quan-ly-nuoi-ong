import 'package:flutter/material.dart';

import '../db/app_database.dart';
import '../widgets/common.dart';

const securityQuestions = [
  'Bạn nuôi loài côn trùng nào?',
  'Tên con vật nuôi đầu tiên của bạn?',
  'Tên trường tiểu học của bạn?',
  'Thành phố bạn sinh ra?',
];

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _user = TextEditingController();
  final _pass = TextEditingController();
  final _pass2 = TextEditingController();
  final _answer = TextEditingController();
  String _question = securityQuestions.first;
  bool _obscure = true;
  bool _busy = false;

  @override
  void dispose() {
    for (final c in [_name, _user, _pass, _pass2, _answer]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _busy = true);
    final ok = await AppDatabase.instance.register(
      username: _user.text,
      fullName: _name.text,
      password: _pass.text,
      question: _question,
      answer: _answer.text,
    );
    if (!mounted) return;
    setState(() => _busy = false);
    if (!ok) {
      showSnack(context, 'Tên đăng nhập đã tồn tại.', error: true);
      return;
    }
    showSnack(context, 'Đăng ký thành công! Hãy đăng nhập.');
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Đăng ký tài khoản')),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(18),
            children: [
              TextFormField(
                controller: _name,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(
                    labelText: 'Họ và tên', prefixIcon: Icon(Icons.badge_outlined)),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Vui lòng nhập họ tên' : null,
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _user,
                autocorrect: false,
                decoration: const InputDecoration(
                    labelText: 'Tên đăng nhập',
                    prefixIcon: Icon(Icons.person_outline)),
                validator: (v) {
                  final t = v?.trim() ?? '';
                  if (t.length < 4) return 'Tối thiểu 4 ký tự';
                  if (!RegExp(r'^[A-Za-z0-9_.]+$').hasMatch(t)) {
                    return 'Chỉ dùng chữ, số, dấu _ và .';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _pass,
                obscureText: _obscure,
                decoration: InputDecoration(
                  labelText: 'Mật khẩu (tối thiểu 6 ký tự)',
                  prefixIcon: const Icon(Icons.lock_outline),
                  suffixIcon: IconButton(
                    icon: Icon(_obscure
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined),
                    onPressed: () => setState(() => _obscure = !_obscure),
                  ),
                ),
                validator: (v) =>
                    (v == null || v.length < 6) ? 'Mật khẩu tối thiểu 6 ký tự' : null,
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _pass2,
                obscureText: _obscure,
                decoration: const InputDecoration(
                    labelText: 'Nhập lại mật khẩu',
                    prefixIcon: Icon(Icons.lock_reset)),
                validator: (v) => v != _pass.text ? 'Mật khẩu nhập lại không khớp' : null,
              ),
              const SizedBox(height: 22),
              const Text('Câu hỏi bảo mật (dùng để lấy lại mật khẩu)',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              PickerField<String>(
                label: 'Câu hỏi',
                value: _question,
                items: securityQuestions,
                itemLabel: (s) => s,
                onChanged: (v) => setState(() => _question = v ?? _question),
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _answer,
                decoration: const InputDecoration(
                    labelText: 'Câu trả lời',
                    prefixIcon: Icon(Icons.help_outline)),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Vui lòng nhập câu trả lời' : null,
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: _busy ? null : _submit,
                child: const Text('ĐĂNG KÝ'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
