import 'package:flutter/material.dart';

import '../db/app_database.dart';
import '../models/models.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'visit_form_screen.dart';

/// Danh sách các lần thăm tổ ong: thêm / sửa / xóa.
class VisitsScreen extends StatefulWidget {
  const VisitsScreen({super.key});

  @override
  State<VisitsScreen> createState() => _VisitsScreenState();
}

class _VisitsScreenState extends State<VisitsScreen> {
  List<Visit> _items = [];
  List<Hive> _hives = [];
  Hive? _filter;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = AppDatabase.instance;
    final hives = await db.hives();
    final visits = await db.visits(hiveId: _filter?.id);
    if (mounted) {
      setState(() {
        _hives = hives;
        _items = visits;
        _loading = false;
      });
    }
  }

  Future<void> _openForm([Visit? v]) async {
    final saved = await Navigator.of(context).push<bool>(MaterialPageRoute(
        builder: (_) => VisitFormScreen(visit: v, initialHiveId: _filter?.id)));
    if (saved == true) _load();
  }

  Future<void> _delete(Visit v) async {
    if (!await confirmDialog(context,
        'Xóa lần thăm thứ ${v.visitNo} của "${v.hiveName}" (${fmtDate(v.visitDate)})?')) {
      return;
    }
    await AppDatabase.instance.deleteVisit(v.id!);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Thăm tổ ong')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openForm(),
        icon: const Icon(Icons.add),
        label: const Text('Ghi nhận lần thăm'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
            child: PickerField<Hive>(
              label: 'Lọc theo tổ ong',
              value: _filter,
              items: _hives,
              itemLabel: (h) => h.name,
              allowClear: true,
              icon: Icons.filter_list,
              onChanged: (h) {
                _filter = h;
                _load();
              },
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _items.isEmpty
                    ? const EmptyState(
                        icon: Icons.fact_check_outlined,
                        text: 'Chưa có lần thăm nào.')
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(12, 8, 12, 90),
                        itemCount: _items.length,
                        itemBuilder: (_, i) => VisitCard(
                          visit: _items[i],
                          onTap: () => _openForm(_items[i]),
                          trailing: PopupMenuButton<String>(
                            onSelected: (v) {
                              if (v == 'edit') _openForm(_items[i]);
                              if (v == 'delete') _delete(_items[i]);
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(value: 'edit', child: Text('Sửa')),
                              PopupMenuItem(value: 'delete', child: Text('Xóa')),
                            ],
                          ),
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}

/// Thẻ hiển thị một lần thăm (dùng lại ở màn hình Tra cứu).
class VisitCard extends StatelessWidget {
  final Visit visit;
  final VoidCallback? onTap;
  final Widget? trailing;
  const VisitCard({super.key, required this.visit, this.onTap, this.trailing});

  @override
  Widget build(BuildContext context) {
    final v = visit;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 4, 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(v.hiveName,
                        style: const TextStyle(
                            fontSize: 17, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text('Lần thăm thứ ${v.visitNo}  •  ${fmtDate(v.visitDate)}',
                        style: const TextStyle(
                            color: AppColors.honeyDark,
                            fontWeight: FontWeight.w700,
                            fontSize: 13.5)),
                    const SizedBox(height: 6),
                    Text(v.condition.isEmpty ? '(chưa ghi tình trạng)' : v.condition),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: [
                        QtyChip(
                            label: 'Mật',
                            grams: v.honey,
                            color: AppColors.honeyTile),
                        QtyChip(
                            label: 'Phấn hoa',
                            grams: v.pollen,
                            color: const Color(0xFFB8860B)),
                        QtyChip(
                            label: 'Keo ong',
                            grams: v.propolis,
                            color: AppColors.propolis),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text('Tách đàn: ${v.splitStatus.isEmpty ? '-' : v.splitStatus}',
                        style:
                            const TextStyle(fontSize: 12.5, color: Colors.black54)),
                  ],
                ),
              ),
              if (trailing != null) trailing! else const SizedBox(width: 10),
            ],
          ),
        ),
      ),
    );
  }
}
