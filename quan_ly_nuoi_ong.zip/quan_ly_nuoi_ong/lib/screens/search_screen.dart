import 'package:flutter/material.dart';

import '../db/app_database.dart';
import '../models/models.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'visits_screen.dart';

/// Tra cứu thông tin tổ ong và lần thăm (không phân biệt hoa/thường, dấu).
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _ctl = TextEditingController();
  List<Hive> _hives = [];
  List<Visit> _visits = [];
  bool _loading = true;
  String _mode = 'hive'; // 'hive' | 'visit'
  String _q = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final db = AppDatabase.instance;
    final h = await db.hives();
    final v = await db.visits();
    if (mounted) {
      setState(() {
        _hives = h;
        _visits = v;
        _loading = false;
      });
    }
  }

  bool _match(String haystack) => normalizeVi(haystack).contains(normalizeVi(_q.trim()));

  List<Hive> get _hiveResults => _q.trim().isEmpty
      ? _hives
      : _hives
          .where((h) => _match(
              '${h.code} ${h.name} ${h.locationName} ${h.characteristics} ${fmtDate(h.createdDate)}'))
          .toList();

  List<Visit> get _visitResults => _q.trim().isEmpty
      ? _visits
      : _visits
          .where((v) => _match(
              '${v.hiveName} ${v.hiveCode} ${v.condition} ${v.splitStatus} lan tham thu ${v.visitNo} ${fmtDate(v.visitDate)}'))
          .toList();

  void _showHive(Hive h) {
    final history = _visits.where((v) => v.hiveId == h.id).toList()
      ..sort((a, b) => a.visitNo.compareTo(b.visitNo));
    final honey = history.fold<double>(0, (s, v) => s + v.honey);
    final pollen = history.fold<double>(0, (s, v) => s + v.pollen);
    final propolis = history.fold<double>(0, (s, v) => s + v.propolis);
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (c) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.75,
        maxChildSize: 0.95,
        builder: (_, scroll) => ListView(
          controller: scroll,
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          children: [
            Text(h.name,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            Text('${h.code}  •  tạo ngày ${fmtDate(h.createdDate)}',
                style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 10),
            _info(Icons.place, h.locationName.isEmpty ? 'Chưa có vị trí' : h.locationName),
            if (h.characteristics.isNotEmpty) _info(Icons.notes, h.characteristics),
            const SizedBox(height: 12),
            Wrap(spacing: 6, runSpacing: 6, children: [
              QtyChip(label: 'Tổng mật', grams: honey, color: AppColors.honeyTile),
              QtyChip(
                  label: 'Tổng phấn hoa',
                  grams: pollen,
                  color: const Color(0xFFB8860B)),
              QtyChip(label: 'Tổng keo', grams: propolis, color: AppColors.propolis),
            ]),
            const SizedBox(height: 16),
            Text('Lịch sử thăm (${history.length} lần)',
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 8),
            if (history.isEmpty)
              const Text('Chưa có lần thăm nào.')
            else
              for (final v in history) VisitCard(visit: v),
          ],
        ),
      ),
    );
  }

  Widget _info(IconData i, String t) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(i, size: 18, color: AppColors.leaf),
            const SizedBox(width: 8),
            Expanded(child: Text(t)),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final hives = _mode == 'hive' ? _hiveResults : const <Hive>[];
    final visits = _mode == 'visit' ? _visitResults : const <Visit>[];
    final count = _mode == 'hive' ? hives.length : visits.length;

    return Scaffold(
      appBar: AppBar(title: const Text('Tra cứu')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
            child: TextField(
              controller: _ctl,
              onChanged: (v) => setState(() => _q = v),
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: _mode == 'hive'
                    ? 'Tìm theo tên, mã, vị trí, đặc điểm...'
                    : 'Tìm theo tổ, tình trạng, ngày (dd/mm/yyyy)...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _q.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () {
                          _ctl.clear();
                          setState(() => _q = '');
                        },
                      ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'hive', label: Text('Tổ ong'), icon: Icon(Icons.hive)),
                ButtonSegment(
                    value: 'visit', label: Text('Lần thăm'), icon: Icon(Icons.fact_check)),
              ],
              selected: {_mode},
              onSelectionChanged: (s) => setState(() => _mode = s.first),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 2),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text('$count kết quả',
                  style: const TextStyle(color: Colors.black54)),
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : count == 0
                    ? const EmptyState(
                        icon: Icons.search_off, text: 'Không tìm thấy kết quả phù hợp.')
                    : ListView(
                        padding: const EdgeInsets.fromLTRB(12, 6, 12, 24),
                        children: [
                          for (final h in hives)
                            Card(
                              margin: const EdgeInsets.only(bottom: 10),
                              child: ListTile(
                                onTap: () => _showHive(h),
                                leading: const CircleAvatar(
                                  backgroundColor: Color(0x33F9A825),
                                  child: Icon(Icons.hive, color: AppColors.honeyTile),
                                ),
                                title: Text(h.name,
                                    style: const TextStyle(fontWeight: FontWeight.w800)),
                                subtitle: Text(
                                    '${h.code}\n${h.locationName.isEmpty ? 'Chưa có vị trí' : h.locationName}'),
                                isThreeLine: true,
                                trailing: const Icon(Icons.chevron_right),
                              ),
                            ),
                          for (final v in visits) VisitCard(visit: v),
                        ],
                      ),
          ),
        ],
      ),
    );
  }
}
