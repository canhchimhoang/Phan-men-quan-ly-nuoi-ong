import 'package:flutter/material.dart';

import '../db/app_database.dart';
import '../models/models.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// Thống kê, báo cáo gồm 3 thẻ:
///  1. Bộ lọc: theo tên tổ, lần thăm thứ n, ngày thăm, tình trạng.
///  2. Theo tổ ong: tổng mật / phấn hoa / keo của từng tổ.
///  3. Theo thời gian: từ ngày ... đến ngày ...
class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Thống kê, báo cáo'),
          bottom: const TabBar(
            labelColor: AppColors.brown,
            indicatorColor: AppColors.brown,
            tabs: [
              Tab(text: 'Bộ lọc'),
              Tab(text: 'Theo tổ ong'),
              Tab(text: 'Theo thời gian'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [_FilterTab(), _PerHiveTab(), _RangeTab()],
        ),
      ),
    );
  }
}

// ======================================================================= TAB 1
class _FilterTab extends StatefulWidget {
  const _FilterTab();

  @override
  State<_FilterTab> createState() => _FilterTabState();
}

class _FilterTabState extends State<_FilterTab>
    with AutomaticKeepAliveClientMixin {
  List<Hive> _hives = [];
  List<int> _nos = [];
  List<String> _conds = [];
  List<Visit> _rows = [];
  Hive? _hive;
  int? _no;
  DateTime? _date;
  String? _cond;
  bool _loading = true;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final db = AppDatabase.instance;
    _hives = await db.hives();
    _nos = await db.distinctVisitNos();
    _conds = await db.distinctConditions();
    await _query();
  }

  Future<void> _query() async {
    final rows = await AppDatabase.instance.visits(
      hiveId: _hive?.id,
      visitNo: _no,
      date: _date,
      condition: _cond,
    );
    if (mounted) {
      setState(() {
        _rows = rows;
        _loading = false;
      });
    }
  }

  void _clear() {
    _hive = null;
    _no = null;
    _date = null;
    _cond = null;
    _query();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final honey = _rows.fold<double>(0, (s, v) => s + v.honey);
    final pollen = _rows.fold<double>(0, (s, v) => s + v.pollen);
    final propolis = _rows.fold<double>(0, (s, v) => s + v.propolis);
    final active = _hive != null || _no != null || _date != null || _cond != null;

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        PickerField<Hive>(
          label: 'Tên tổ ong',
          value: _hive,
          items: _hives,
          itemLabel: (h) => h.name,
          allowClear: true,
          onChanged: (h) {
            _hive = h;
            _query();
          },
        ),
        const SizedBox(height: 10),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: PickerField<int>(
                label: 'Lần thăm thứ',
                value: _no,
                items: _nos,
                itemLabel: (n) => 'Lần $n',
                allowClear: true,
                onChanged: (n) {
                  _no = n;
                  _query();
                },
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: DateField(
                label: 'Ngày thăm',
                value: _date,
                allowClear: true,
                onChanged: (d) {
                  _date = d;
                  _query();
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        PickerField<String>(
          label: 'Tình trạng tổ ong',
          value: _cond,
          items: _conds,
          itemLabel: (s) => s,
          allowClear: true,
          onChanged: (s) {
            _cond = s;
            _query();
          },
        ),
        if (active)
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: _clear,
              icon: const Icon(Icons.filter_alt_off),
              label: const Text('Xóa bộ lọc'),
            ),
          ),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(
              child: StatTile(
                  label: 'Số lần thăm',
                  value: '${_rows.length}',
                  icon: Icons.fact_check,
                  color: AppColors.propolis)),
          const SizedBox(width: 8),
          Expanded(
              child: StatTile(
                  label: 'Tổng mật',
                  value: fmtGram(honey),
                  icon: Icons.water_drop,
                  color: AppColors.honeyTile)),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(
              child: StatTile(
                  label: 'Tổng phấn hoa',
                  value: fmtGram(pollen),
                  icon: Icons.local_florist,
                  color: const Color(0xFFB8860B))),
          const SizedBox(width: 8),
          Expanded(
              child: StatTile(
                  label: 'Tổng keo ong',
                  value: fmtGram(propolis),
                  icon: Icons.bubble_chart,
                  color: AppColors.propolis)),
        ]),
        const SizedBox(height: 14),
        if (_loading)
          const Center(child: CircularProgressIndicator())
        else if (_rows.isEmpty)
          const SizedBox(
              height: 160,
              child: EmptyState(
                  icon: Icons.search_off, text: 'Không có lần thăm nào khớp bộ lọc.'))
        else
          Card(
            clipBehavior: Clip.antiAlias,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                headingRowColor: WidgetStateProperty.all(const Color(0xFFFFE9A8)),
                columnSpacing: 18,
                columns: const [
                  DataColumn(label: Text('Tổ ong')),
                  DataColumn(label: Text('Lần')),
                  DataColumn(label: Text('Ngày')),
                  DataColumn(label: Text('Tình trạng')),
                  DataColumn(label: Text('Mật (g)'), numeric: true),
                  DataColumn(label: Text('Phấn hoa (g)'), numeric: true),
                  DataColumn(label: Text('Keo (g)'), numeric: true),
                  DataColumn(label: Text('Tách đàn')),
                ],
                rows: [
                  for (final v in _rows)
                    DataRow(cells: [
                      DataCell(Text(v.hiveName)),
                      DataCell(Text('${v.visitNo}')),
                      DataCell(Text(fmtDate(v.visitDate))),
                      DataCell(Text(v.condition)),
                      DataCell(Text(fmtNum(v.honey))),
                      DataCell(Text(fmtNum(v.pollen))),
                      DataCell(Text(fmtNum(v.propolis))),
                      DataCell(Text(v.splitStatus)),
                    ]),
                  DataRow(cells: [
                    const DataCell(Text('TỔNG',
                        style: TextStyle(fontWeight: FontWeight.w800))),
                    const DataCell(Text('')),
                    const DataCell(Text('')),
                    const DataCell(Text('')),
                    DataCell(Text(fmtNum(honey),
                        style: const TextStyle(fontWeight: FontWeight.w800))),
                    DataCell(Text(fmtNum(pollen),
                        style: const TextStyle(fontWeight: FontWeight.w800))),
                    DataCell(Text(fmtNum(propolis),
                        style: const TextStyle(fontWeight: FontWeight.w800))),
                    const DataCell(Text('')),
                  ]),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

// Bảng tổng hợp theo từng tổ (dùng cho tab 2 và tab 3).
Widget _totalsTable(List<HiveTotal> list) {
  final visits = list.fold<int>(0, (s, t) => s + t.visits);
  final honey = list.fold<double>(0, (s, t) => s + t.honey);
  final pollen = list.fold<double>(0, (s, t) => s + t.pollen);
  final propolis = list.fold<double>(0, (s, t) => s + t.propolis);
  const bold = TextStyle(fontWeight: FontWeight.w800);
  return Card(
    clipBehavior: Clip.antiAlias,
    child: SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: DataTable(
        headingRowColor: WidgetStateProperty.all(const Color(0xFFFFE9A8)),
        columnSpacing: 22,
        columns: const [
          DataColumn(label: Text('Tổ ong')),
          DataColumn(label: Text('Số lần thăm'), numeric: true),
          DataColumn(label: Text('Mật (g)'), numeric: true),
          DataColumn(label: Text('Phấn hoa (g)'), numeric: true),
          DataColumn(label: Text('Keo ong (g)'), numeric: true),
        ],
        rows: [
          for (final t in list)
            DataRow(cells: [
              DataCell(Text(t.name)),
              DataCell(Text('${t.visits}')),
              DataCell(Text(fmtNum(t.honey))),
              DataCell(Text(fmtNum(t.pollen))),
              DataCell(Text(fmtNum(t.propolis))),
            ]),
          DataRow(cells: [
            const DataCell(Text('TỔNG', style: bold)),
            DataCell(Text('$visits', style: bold)),
            DataCell(Text(fmtNum(honey), style: bold)),
            DataCell(Text(fmtNum(pollen), style: bold)),
            DataCell(Text(fmtNum(propolis), style: bold)),
          ]),
        ],
      ),
    ),
  );
}

Widget _totalTiles(List<HiveTotal> list) {
  final honey = list.fold<double>(0, (s, t) => s + t.honey);
  final pollen = list.fold<double>(0, (s, t) => s + t.pollen);
  final propolis = list.fold<double>(0, (s, t) => s + t.propolis);
  return Row(children: [
    Expanded(
        child: StatTile(
            label: 'Tổng mật',
            value: fmtGram(honey),
            icon: Icons.water_drop,
            color: AppColors.honeyTile)),
    const SizedBox(width: 8),
    Expanded(
        child: StatTile(
            label: 'Tổng phấn hoa',
            value: fmtGram(pollen),
            icon: Icons.local_florist,
            color: const Color(0xFFB8860B))),
    const SizedBox(width: 8),
    Expanded(
        child: StatTile(
            label: 'Tổng keo ong',
            value: fmtGram(propolis),
            icon: Icons.bubble_chart,
            color: AppColors.propolis)),
  ]);
}

// ======================================================================= TAB 2
class _PerHiveTab extends StatefulWidget {
  const _PerHiveTab();

  @override
  State<_PerHiveTab> createState() => _PerHiveTabState();
}

class _PerHiveTabState extends State<_PerHiveTab> {
  List<HiveTotal>? _list;

  @override
  void initState() {
    super.initState();
    AppDatabase.instance.totalsPerHive().then((l) {
      if (mounted) setState(() => _list = l);
    });
  }

  @override
  Widget build(BuildContext context) {
    final l = _list;
    if (l == null) return const Center(child: CircularProgressIndicator());
    if (l.isEmpty) {
      return const EmptyState(icon: Icons.hive_outlined, text: 'Chưa có tổ ong nào.');
    }
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        const Text('Tổng số lượng mật, phấn hoa, keo ong của từng tổ ong',
            style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        _totalTiles(l),
        const SizedBox(height: 12),
        _totalsTable(l),
      ],
    );
  }
}

// ======================================================================= TAB 3
class _RangeTab extends StatefulWidget {
  const _RangeTab();

  @override
  State<_RangeTab> createState() => _RangeTabState();
}

class _RangeTabState extends State<_RangeTab> {
  late DateTime _from;
  late DateTime _to;
  List<HiveTotal>? _list;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _from = DateTime(now.year, now.month, 1);
    _to = dateOnly(now);
    _query();
  }

  Future<void> _query() async {
    if (_from.isAfter(_to)) {
      setState(() => _list = const []);
      return;
    }
    final l = await AppDatabase.instance.totalsPerHive(from: _from, to: _to);
    if (mounted) setState(() => _list = l);
  }

  @override
  Widget build(BuildContext context) {
    final invalid = _from.isAfter(_to);
    final l = _list;
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: DateField(
                label: 'Từ ngày',
                value: _from,
                onChanged: (d) {
                  _from = d ?? _from;
                  _query();
                },
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: DateField(
                label: 'Đến ngày',
                value: _to,
                errorText: invalid ? 'Phải sau "Từ ngày"' : null,
                onChanged: (d) {
                  _to = d ?? _to;
                  _query();
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        if (l == null)
          const Center(child: CircularProgressIndicator())
        else if (!invalid) ...[
          Text(
              'Sản lượng từ ${fmtDate(_from)} đến ${fmtDate(_to)}',
              style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          _totalTiles(l),
          const SizedBox(height: 12),
          if (l.every((t) => t.visits == 0))
            const SizedBox(
                height: 140,
                child: EmptyState(
                    icon: Icons.event_busy,
                    text: 'Không có lần thăm nào trong khoảng thời gian này.'))
          else
            _totalsTable(l),
        ],
      ],
    );
  }
}
