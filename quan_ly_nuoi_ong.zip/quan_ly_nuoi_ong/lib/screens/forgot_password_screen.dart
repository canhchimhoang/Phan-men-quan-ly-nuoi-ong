import 'package:flutter/material.dart';

import '../db/app_database.dart';
import '../widgets/common.dart';

/// Lấy lại mật khẩu bằng câu hỏi bảo mật (ứng dụng lưu dữ liệu trên máy nên
/// không gửi email được).
class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _user = TextEditingController();
  final _answer = TextEditingController();
  final _pass = TextEditingController();
  final _pass2 = TextEditingController();
  final _step1 = GlobalKey<FormState>();
  final _step2 = GlobalKey<FormState>();
  String? _question;
  bool _busy = false;

  @override
  void dispose() {
    for (final c in [_user, _answer, _pass, _pass2]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _findUser() async {
    if (!_step1.currentState!.validate()) return;
    setState(() => _busy = true);
    final q = await AppDatabase.instance.securityQuestion(_user.text);
    if (!mounted) return;
    setState(() {
      _busy = false;
      _question = q;
    });
    if (q == null) showSnack(context, 'Không tìm thấy tên đăng nhập này.', error: true);
  }

  Future<void> _reset() async {
    if (!_step2.currentState!.validate()) return;
    setState(() => _busy = true);
    final ok = await AppDatabase.instance
        .resetPassword(_user.text, _answer.text, _pass.text);
    if (!mounted) return;
    setState(() => _busy = false);
    if (!ok) {
      showSnack(context, 'Câu trả lời bảo mật không đúng.', error: true);
      return;
    }
    showSnack(context, 'Đã đặt lại mật khẩu. Hãy đăng nhập lại.');
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Quên mật khẩu')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Form(
              key: _step1,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  TextFormField(
                    controller: _user,
                    enabled: _question == null,
                    autocorrect: false,
                    decoration: const InputDecoration(
                        labelText: 'Tên đăng nhập',
                        prefixIcon: Icon(Icons.person_outline)),
                    validator: (v) => (v == null || v.trim().isEmpty)
                        ? 'Vui lòng nhập tên đăng nhập'
                        : null,
                  ),
                  if (_question == null) ...[
                    const SizedBox(height: 16),
                    FilledButton(
                      onPressed: _busy ? null : _findUser,
                      child: const Text('TIẾP TỤC'),
                    ),
                  ],
                ],
              ),
            ),
            if (_question != null)
              Form(
                key: _step2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const SizedBox(height: 20),
                    Text('Câu hỏi bảo mật: $_question',
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: _answer,
                      decoration: const InputDecoration(
                          labelText: 'Câu trả lời',
                          prefixIcon: Icon(Icons.help_outline)),
                      validator: (v) => (v == null || v.trim().isEmpty)
                          ? 'Vui lòng nhập câu trả lời'
                          : null,
                    ),
                    const SizedBox(height: 14),
                    TextFormField(
                      controller: _pass,
                      obscureText: true,
                      decoration: const InputDecoration(
                          labelText: 'Mật khẩu mới (tối thiểu 6 ký tự)',
                          prefixIcon: Icon(Icons.lock_outline)),
                      validator: (v) => (v == null || v.length < 6)
                          ? 'Mật khẩu tối thiểu 6 ký tự'
                          : null,
                    ),
                    const SizedBox(height: 14),
                    TextFormField(
                      controller: _pass2,
                      obscureText: true,
                      decoration: const InputDecoration(
                          labelText: 'Nhập lại mật khẩu mới',
                          prefixIcon: Icon(Icons.lock_reset)),
                      validator: (v) =>
                          v != _pass.text ? 'Mật khẩu nhập lại không khớp' : null,
                    ),
                    const SizedBox(height: 20),
                    FilledButton(
                      onPressed: _busy ? null : _reset,
                      child: const Text('ĐẶT LẠI MẬT KHẨU'),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
