import 'package:flutter/material.dart';

import '../db/app_database.dart';
import '../models/models.dart';
import '../widgets/common.dart';
import 'locations_screen.dart';

/// Form thêm / sửa tổ ong. Trả về true nếu đã lưu.
class HiveFormScreen extends StatefulWidget {
  final Hive? hive;
  const HiveFormScreen({super.key, this.hive});

  @override
  State<HiveFormScreen> createState() => _HiveFormScreenState();
}

class _HiveFormScreenState extends State<HiveFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _code = TextEditingController();
  final _name = TextEditingController();
  final _feature = TextEditingController();
  DateTime _created = dateOnly(DateTime.now());
  List<HiveLocation> _locations = [];
  int? _locationId;
  bool _busy = false;

  bool get _isEdit => widget.hive != null;

  @override
  void initState() {
    super.initState();
    final h = widget.hive;
    if (h != null) {
      _code.text = h.code;
      _name.text = h.name;
      _feature.text = h.characteristics;
      _created = dateOnly(h.createdDate);
      _locationId = h.locationId;
    } else {
      AppDatabase.instance.nextHiveCode().then((c) {
        if (mounted) _code.text = c;
      });
    }
    _loadLocations();
  }

  @override
  void dispose() {
    _code.dispose();
    _name.dispose();
    _feature.dispose();
    super.dispose();
  }

  Future<void> _loadLocations() async {
    final l = await AppDatabase.instance.locations();
    if (mounted) setState(() => _locations = l);
  }

  HiveLocation? get _selected {
    for (final l in _locations) {
      if (l.id == _locationId) return l;
    }
    return null;
  }

  Future<void> _addLocation() async {
    final id = await showLocationDialog(context);
    if (id == null) return;
    await _loadLocations();
    setState(() => _locationId = id);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final db = AppDatabase.instance;
    setState(() => _busy = true);
    try {
      if (await db.hiveCodeOrNameTaken(_code.text, _name.text, widget.hive?.id)) {
        if (mounted) {
          showSnack(context, 'Mã tổ hoặc tên tổ đã tồn tại.', error: true);
        }
        return;
      }
      final h = Hive(
        id: widget.hive?.id,
        code: _code.text,
        name: _name.text,
        locationId: _locationId,
        characteristics: _feature.text,
        createdDate: _created,
      );
      if (_isEdit) {
        await db.updateHive(h);
      } else {
        await db.insertHive(h);
      }
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) showSnack(context, 'Không lưu được: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? 'Sửa tổ ong' : 'Thêm tổ ong')),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              TextFormField(
                controller: _code,
                decoration: const InputDecoration(
                    labelText: 'Mã tổ ong', prefixIcon: Icon(Icons.tag)),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Vui lòng nhập mã tổ' : null,
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _name,
                textCapitalization: TextCapitalization.sentences,
                decoration: const InputDecoration(
                    labelText: 'Tên tổ ong', prefixIcon: Icon(Icons.hive)),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Vui lòng nhập tên tổ' : null,
              ),
              const SizedBox(height: 14),
              PickerField<HiveLocation>(
                label: 'Vị trí của tổ ong',
                value: _selected,
                items: _locations,
                itemLabel: (l) => l.name,
                allowClear: true,
                clearLabel: 'Chưa có vị trí',
                icon: Icons.place,
                onChanged: (l) => setState(() => _locationId = l?.id),
              ),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: _addLocation,
                  icon: const Icon(Icons.add_location_alt),
                  label: const Text('Thêm vị trí mới'),
                ),
              ),
              const SizedBox(height: 4),
              TextFormField(
                controller: _feature,
                minLines: 3,
                maxLines: 6,
                textCapitalization: TextCapitalization.sentences,
                decoration: const InputDecoration(
                  labelText: 'Đặc điểm của tổ ong',
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 14),
              DateField(
                label: 'Ngày tạo tổ ong',
                value: _created,
                onChanged: (d) => setState(() => _created = d ?? _created),
              ),
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: _busy ? null : _save,
                icon: const Icon(Icons.save),
                label: const Text('LƯU'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
