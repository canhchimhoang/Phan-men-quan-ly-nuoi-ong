import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../theme.dart';

// ------------------------------------------------------------------ ĐỊNH DẠNG
final _dateFmt = DateFormat('dd/MM/yyyy');
final _dateTimeFmt = DateFormat('dd/MM/yyyy HH:mm');

String fmtDate(DateTime d) => _dateFmt.format(d);
String fmtDateTime(DateTime d) => _dateTimeFmt.format(d);

/// 1200 -> "1200", 12.5 -> "12.5"
String fmtNum(double v) =>
    v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(1);
String fmtGram(double v) => '${fmtNum(v)} g';

DateTime dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

/// Bỏ dấu tiếng Việt + chữ thường, dùng cho tìm kiếm không phân biệt dấu.
String normalizeVi(String s) {
  const groups = {
    'a': 'àáạảãâầấậẩẫăằắặẳẵ',
    'e': 'èéẹẻẽêềếệểễ',
    'i': 'ìíịỉĩ',
    'o': 'òóọỏõôồốộổỗơờớợởỡ',
    'u': 'ùúụủũưừứựửữ',
    'y': 'ỳýỵỷỹ',
    'd': 'đ',
  };
  final map = <String, String>{};
  groups.forEach((base, chars) {
    for (final c in chars.split('')) {
      map[c] = base;
    }
  });
  final lower = s.toLowerCase();
  final b = StringBuffer();
  for (final ch in lower.split('')) {
    b.write(map[ch] ?? ch);
  }
  return b.toString();
}

// ------------------------------------------------------------------ HỘP THOẠI
void showSnack(BuildContext context, String msg, {bool error = false}) {
  final m = ScaffoldMessenger.of(context);
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(
    content: Text(msg),
    backgroundColor: error ? Colors.red.shade700 : AppColors.brown,
    behavior: SnackBarBehavior.floating,
  ));
}

Future<bool> confirmDialog(BuildContext context, String message,
    {String title = 'Xác nhận', String okText = 'Xóa'}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(c, false), child: const Text('Hủy')),
        FilledButton(
          style: FilledButton.styleFrom(
              minimumSize: const Size(90, 44), backgroundColor: Colors.red.shade700),
          onPressed: () => Navigator.pop(c, true),
          child: Text(okText),
        ),
      ],
    ),
  );
  return r ?? false;
}

// ------------------------------------------------------------------ Ô CHỌN
class _Pick<T> {
  final T? value;
  const _Pick(this.value);
}

/// Ô chọn một giá trị trong danh sách (mở bảng chọn từ dưới lên).
class PickerField<T> extends StatelessWidget {
  final String label;
  final T? value;
  final List<T> items;
  final String Function(T) itemLabel;
  final ValueChanged<T?> onChanged;
  final bool allowClear;
  final String clearLabel;
  final String? errorText;
  final IconData icon;
  final String hint;

  const PickerField({
    super.key,
    required this.label,
    required this.value,
    required this.items,
    required this.itemLabel,
    required this.onChanged,
    this.allowClear = false,
    this.clearLabel = 'Tất cả',
    this.errorText,
    this.icon = Icons.arrow_drop_down,
    this.hint = 'Chọn...',
  });

  Future<void> _open(BuildContext context) async {
    final res = await showModalBottomSheet<_Pick<T>>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (c) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(
              maxHeight: MediaQuery.of(c).size.height * 0.7),
          child: items.isEmpty && !allowClear
              ? const Padding(
                  padding: EdgeInsets.all(32),
                  child: Text('Chưa có dữ liệu để chọn.'),
                )
              : ListView(
                  shrinkWrap: true,
                  children: [
                    if (allowClear)
                      ListTile(
                        leading: const Icon(Icons.clear_all),
                        title: Text(clearLabel),
                        onTap: () => Navigator.pop(c, _Pick<T>(null)),
                      ),
                    for (final it in items)
                      ListTile(
                        title: Text(itemLabel(it)),
                        selected: it == value,
                        trailing: it == value ? const Icon(Icons.check) : null,
                        onTap: () => Navigator.pop(c, _Pick<T>(it)),
                      ),
                  ],
                ),
        ),
      ),
    );
    if (res != null) onChanged(res.value);
  }

  @override
  Widget build(BuildContext context) {
    final has = value != null;
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => _open(context),
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          errorText: errorText,
          suffixIcon: Icon(icon),
        ),
        child: Text(
          has ? itemLabel(value as T) : (allowClear ? clearLabel : hint),
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
              fontSize: 16, color: has ? Colors.black87 : Colors.black45),
        ),
      ),
    );
  }
}

/// Ô chọn ngày.
class DateField extends StatelessWidget {
  final String label;
  final DateTime? value;
  final ValueChanged<DateTime?> onChanged;
  final bool allowClear;
  final String? errorText;

  const DateField({
    super.key,
    required this.label,
    required this.value,
    required this.onChanged,
    this.allowClear = false,
    this.errorText,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () async {
        final now = DateTime.now();
        final picked = await showDatePicker(
          context: context,
          initialDate: value ?? now,
          firstDate: DateTime(2000),
          lastDate: DateTime(2100),
          helpText: label,
          cancelText: 'Hủy',
          confirmText: 'Chọn',
        );
        if (picked != null) onChanged(dateOnly(picked));
      },
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          errorText: errorText,
          suffixIcon: (allowClear && value != null)
              ? IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => onChanged(null),
                )
              : const Icon(Icons.calendar_month),
        ),
        child: Text(
          value == null ? (allowClear ? 'Tất cả' : 'Chọn ngày') : fmtDate(value!),
          style: TextStyle(
              fontSize: 16,
              color: value == null ? Colors.black45 : Colors.black87),
        ),
      ),
    );
  }
}

// ------------------------------------------------------------------ KHÁC
class EmptyState extends StatelessWidget {
  final IconData icon;
  final String text;
  const EmptyState({super.key, required this.icon, required this.text});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 64, color: AppColors.honey),
              const SizedBox(height: 12),
              Text(text,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 16, color: Colors.black54)),
            ],
          ),
        ),
      );
}

/// Nhãn nhỏ "Mật 200 g" / "Phấn hoa 50 g" / "Keo ong 10 g".
class QtyChip extends StatelessWidget {
  final String label;
  final double grams;
  final Color color;
  const QtyChip(
      {super.key, required this.label, required this.grams, required this.color});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: color.withAlpha(36),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withAlpha(120)),
        ),
        child: Text('$label ${fmtGram(grams)}',
            style: TextStyle(
                fontSize: 12.5, fontWeight: FontWeight.w600, color: color)),
      );
}

class StatTile extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  const StatTile({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withAlpha(90)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color),
            const SizedBox(height: 6),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(value,
                  style: TextStyle(
                      fontSize: 20, fontWeight: FontWeight.w800, color: color)),
            ),
            Text(label,
                style: const TextStyle(fontSize: 12.5, color: Colors.black54)),
          ],
        ),
      );
}
