import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/models.dart';

/// Toàn bộ truy cập SQLite của ứng dụng.
///
/// Các bảng: users, locations, hives, visits, reminders.
/// Ngày lưu dạng ISO (yyyy-MM-dd) để so sánh/lọc theo chuỗi được chính xác.
class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  Database? _db;

  Future<Database> get db async => _db ??= await _open();

  Future<Database> _open() async {
    final path = p.join(await getDatabasesPath(), 'nuoi_ong.db');
    return openDatabase(
      path,
      version: 1,
      onConfigure: (d) async => d.execute('PRAGMA foreign_keys = ON'),
      onCreate: (d, v) async {
        await _createTables(d);
        await _seed(d);
      },
    );
  }

  Future<void> _createTables(Database d) async {
    await d.execute('''
      CREATE TABLE users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        full_name TEXT,
        password_hash TEXT NOT NULL,
        salt TEXT NOT NULL,
        question TEXT,
        answer_hash TEXT
      )''');
    await d.execute('''
      CREATE TABLE locations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE
      )''');
    await d.execute('''
      CREATE TABLE hives(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL UNIQUE,
        location_id INTEGER REFERENCES locations(id) ON DELETE SET NULL,
        characteristics TEXT,
        created_date TEXT NOT NULL
      )''');
    await d.execute('''
      CREATE TABLE visits(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        hive_id INTEGER NOT NULL REFERENCES hives(id) ON DELETE CASCADE,
        visit_no INTEGER NOT NULL,
        visit_date TEXT NOT NULL,
        condition TEXT,
        honey_g REAL NOT NULL DEFAULT 0,
        pollen_g REAL NOT NULL DEFAULT 0,
        propolis_g REAL NOT NULL DEFAULT 0,
        split_status TEXT,
        UNIQUE(hive_id, visit_no)
      )''');
    await d.execute('''
      CREATE TABLE reminders(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        hive_id INTEGER NOT NULL REFERENCES hives(id) ON DELETE CASCADE,
        remind_at TEXT NOT NULL,
        note TEXT,
        done INTEGER NOT NULL DEFAULT 0
      )''');
  }

  // ---------------------------------------------------------------- DỮ LIỆU MẪU
  // Theo file "phần mềm quản lý nuôi ong.xlsx". Các ngày trong file Excel bị lẫn
  // định dạng ngày/tháng (ví dụ 02/11 bị đọc thành 11/02); ở đây đã chuẩn hóa
  // tất cả về dạng ngày/tháng/năm.
  Future<void> _seed(Database d) async {
    final salt = _newSalt();
    await d.insert('users', {
      'username': 'admin',
      'full_name': 'Quản trị viên',
      'password_hash': _hash('123456', salt),
      'salt': salt,
      'question': 'Bạn nuôi loài côn trùng nào?',
      'answer_hash': _hash('ong', salt),
    });

    final a = await d.insert(
        'locations', {'name': 'Khu A; Vườn Phi; xã Thạch Mỹ; TP. Đà Nẵng'});
    final b = await d.insert(
        'locations', {'name': 'Khu B; Vườn Phi; xã Thạch Mỹ; TP. Đà Nẵng'});
    final c = await d.insert(
        'locations', {'name': 'Khu sảnh, vườn Khánh; Ở Bồ Bồ, TP. Đà Nẵng'});

    const feat = 'Tổ mới tách, có đầy đủ trứng, keo, phấn hoa, mật và ong Chúa';
    final h1 = await d.insert('hives', {
      'code': 'ong_0001',
      'name': 'Tổ Ong Dú 1',
      'location_id': a,
      'characteristics': feat,
      'created_date': '2026-10-29',
    });
    final h2 = await d.insert('hives', {
      'code': 'ong_0002',
      'name': 'Tổ Ong Dú 2',
      'location_id': b,
      'characteristics': '$feat, Nắp bị hư',
      'created_date': '2026-11-02',
    });
    final h3 = await d.insert('hives', {
      'code': 'ong_0003',
      'name': 'Tổ Ong Dú 3',
      'location_id': c,
      'characteristics': feat,
      'created_date': '2026-11-10',
    });

    Future<void> v(int hive, int no, String date, String cond, double honey,
            double pollen, double propolis) =>
        d.insert('visits', {
          'hive_id': hive,
          'visit_no': no,
          'visit_date': date,
          'condition': cond,
          'honey_g': honey,
          'pollen_g': pollen,
          'propolis_g': propolis,
          'split_status': 'chưa',
        });
    const good = 'Đàn ong phát triển tốt';
    await v(h1, 1, '2026-11-10', good, 200, 50, 10);
    await v(h3, 1, '2026-11-10', good, 0, 10, 0);
    await v(h2, 1, '2026-11-09', 'Đàn ong phát triển hơi kém', 10, 0, 20);
    await v(h1, 2, '2026-11-15', good, 0, 10, 0);
    await v(h2, 2, '2026-11-16', good, 0, 0, 10);
  }

  // ---------------------------------------------------------------- TÀI KHOẢN
  static String _newSalt() {
    final r = Random.secure();
    return base64UrlEncode(List<int>.generate(16, (_) => r.nextInt(256)));
  }

  static String _hash(String text, String salt) =>
      sha256.convert(utf8.encode('$salt|$text')).toString();

  Future<AppUser?> login(String username, String password) async {
    final d = await db;
    final rows = await d.query('users',
        where: 'username = ? COLLATE NOCASE', whereArgs: [username.trim()]);
    if (rows.isEmpty) return null;
    final u = rows.first;
    final ok = u['password_hash'] == _hash(password, u['salt'] as String);
    return ok ? AppUser.fromMap(u) : null;
  }

  /// Trả về false nếu tên đăng nhập đã tồn tại.
  Future<bool> register({
    required String username,
    required String fullName,
    required String password,
    required String question,
    required String answer,
  }) async {
    final d = await db;
    final exists = await d.query('users',
        where: 'username = ? COLLATE NOCASE', whereArgs: [username.trim()]);
    if (exists.isNotEmpty) return false;
    final salt = _newSalt();
    await d.insert('users', {
      'username': username.trim(),
      'full_name': fullName.trim(),
      'password_hash': _hash(password, salt),
      'salt': salt,
      'question': question,
      'answer_hash': _hash(answer.trim().toLowerCase(), salt),
    });
    return true;
  }

  Future<String?> securityQuestion(String username) async {
    final d = await db;
    final rows = await d.query('users',
        columns: ['question'],
        where: 'username = ? COLLATE NOCASE',
        whereArgs: [username.trim()]);
    if (rows.isEmpty) return null;
    return rows.first['question'] as String?;
  }

  Future<bool> resetPassword(
      String username, String answer, String newPassword) async {
    final d = await db;
    final rows = await d.query('users',
        where: 'username = ? COLLATE NOCASE', whereArgs: [username.trim()]);
    if (rows.isEmpty) return false;
    final u = rows.first;
    final okAnswer =
        u['answer_hash'] == _hash(answer.trim().toLowerCase(), u['salt'] as String);
    if (!okAnswer) return false;
    final salt = _newSalt();
    await d.update(
      'users',
      {
        'password_hash': _hash(newPassword, salt),
        'salt': salt,
        // Đổi salt nên phải băm lại câu trả lời bảo mật với salt mới.
        'answer_hash': _hash(answer.trim().toLowerCase(), salt),
      },
      where: 'id = ?',
      whereArgs: [u['id']],
    );
    return true;
  }

  Future<AppUser?> userByName(String username) async {
    final d = await db;
    final rows = await d.query('users',
        where: 'username = ? COLLATE NOCASE', whereArgs: [username]);
    return rows.isEmpty ? null : AppUser.fromMap(rows.first);
  }

  // ---------------------------------------------------------------- VỊ TRÍ
  Future<List<HiveLocation>> locations() async {
    final d = await db;
    final rows = await d.rawQuery('''
      SELECT l.id, l.name, COUNT(h.id) AS hive_count
      FROM locations l LEFT JOIN hives h ON h.location_id = l.id
      GROUP BY l.id ORDER BY l.name COLLATE NOCASE''');
    return rows.map(HiveLocation.fromMap).toList();
  }

  Future<int> insertLocation(String name) async =>
      (await db).insert('locations', {'name': name.trim()});

  Future<void> updateLocation(int id, String name) async => (await db)
      .update('locations', {'name': name.trim()}, where: 'id = ?', whereArgs: [id]);

  Future<void> deleteLocation(int id) async =>
      (await db).delete('locations', where: 'id = ?', whereArgs: [id]);

  // ---------------------------------------------------------------- TỔ ONG
  static const _hiveSelect = '''
      SELECT h.*, l.name AS location_name
      FROM hives h LEFT JOIN locations l ON l.id = h.location_id''';

  Future<List<Hive>> hives() async {
    final rows = await (await db).rawQuery('$_hiveSelect ORDER BY h.code');
    return rows.map(Hive.fromMap).toList();
  }

  Future<String> nextHiveCode() async {
    final rows = await (await db).query('hives', columns: ['code']);
    var maxNo = 0;
    for (final r in rows) {
      final m = RegExp(r'(\d+)$').firstMatch(r['code'] as String);
      if (m != null) maxNo = max(maxNo, int.parse(m.group(1)!));
    }
    return 'ong_${(maxNo + 1).toString().padLeft(4, '0')}';
  }

  Map<String, Object?> _hiveMap(Hive h) => {
        'code': h.code.trim(),
        'name': h.name.trim(),
        'location_id': h.locationId,
        'characteristics': h.characteristics.trim(),
        'created_date': _iso(h.createdDate),
      };

  Future<void> insertHive(Hive h) async => (await db).insert('hives', _hiveMap(h));

  Future<void> updateHive(Hive h) async =>
      (await db).update('hives', _hiveMap(h), where: 'id = ?', whereArgs: [h.id]);

  Future<void> deleteHive(int id) async =>
      (await db).delete('hives', where: 'id = ?', whereArgs: [id]);

  Future<bool> hiveCodeOrNameTaken(String code, String name, int? exceptId) async {
    final rows = await (await db).query('hives',
        where: '(code = ? COLLATE NOCASE OR name = ? COLLATE NOCASE) AND id <> ?',
        whereArgs: [code.trim(), name.trim(), exceptId ?? -1]);
    return rows.isNotEmpty;
  }

  Future<int> visitCountOfHive(int hiveId) async {
    final r = await (await db)
        .rawQuery('SELECT COUNT(*) c FROM visits WHERE hive_id = ?', [hiveId]);
    return (r.first['c'] as int?) ?? 0;
  }

  // ---------------------------------------------------------------- LẦN THĂM
  /// Truy vấn lần thăm với các bộ lọc tùy chọn.
  Future<List<Visit>> visits({
    int? hiveId,
    int? visitNo,
    DateTime? date,
    String? condition,
    DateTime? from,
    DateTime? to,
  }) async {
    final where = <String>[];
    final args = <Object?>[];
    if (hiveId != null) {
      where.add('v.hive_id = ?');
      args.add(hiveId);
    }
    if (visitNo != null) {
      where.add('v.visit_no = ?');
      args.add(visitNo);
    }
    if (date != null) {
      where.add('v.visit_date = ?');
      args.add(_iso(date));
    }
    if (condition != null && condition.isNotEmpty) {
      where.add('v.condition = ?');
      args.add(condition);
    }
    if (from != null) {
      where.add('v.visit_date >= ?');
      args.add(_iso(from));
    }
    if (to != null) {
      where.add('v.visit_date <= ?');
      args.add(_iso(to));
    }
    final rows = await (await db).rawQuery('''
      SELECT v.*, h.name AS hive_name, h.code AS hive_code
      FROM visits v JOIN hives h ON h.id = v.hive_id
      ${where.isEmpty ? '' : 'WHERE ${where.join(' AND ')}'}
      ORDER BY v.visit_date DESC, h.code, v.visit_no''', args);
    return rows.map(Visit.fromMap).toList();
  }

  Map<String, Object?> _visitMap(Visit v) => {
        'hive_id': v.hiveId,
        'visit_no': v.visitNo,
        'visit_date': _iso(v.visitDate),
        'condition': v.condition.trim(),
        'honey_g': v.honey,
        'pollen_g': v.pollen,
        'propolis_g': v.propolis,
        'split_status': v.splitStatus.trim(),
      };

  Future<void> insertVisit(Visit v) async => (await db).insert('visits', _visitMap(v));

  Future<void> updateVisit(Visit v) async =>
      (await db).update('visits', _visitMap(v), where: 'id = ?', whereArgs: [v.id]);

  Future<void> deleteVisit(int id) async =>
      (await db).delete('visits', where: 'id = ?', whereArgs: [id]);

  Future<int> nextVisitNo(int hiveId) async {
    final r = await (await db).rawQuery(
        'SELECT COALESCE(MAX(visit_no),0) m FROM visits WHERE hive_id = ?', [hiveId]);
    return ((r.first['m'] as int?) ?? 0) + 1;
  }

  Future<bool> visitNoTaken(int hiveId, int visitNo, int? exceptId) async {
    final rows = await (await db).query('visits',
        where: 'hive_id = ? AND visit_no = ? AND id <> ?',
        whereArgs: [hiveId, visitNo, exceptId ?? -1]);
    return rows.isNotEmpty;
  }

  Future<List<int>> distinctVisitNos() async {
    final rows = await (await db)
        .rawQuery('SELECT DISTINCT visit_no FROM visits ORDER BY visit_no');
    return rows.map((r) => r['visit_no'] as int).toList();
  }

  Future<List<String>> distinctConditions() async {
    final rows = await (await db).rawQuery(
        "SELECT DISTINCT condition FROM visits WHERE condition <> '' ORDER BY condition");
    return rows.map((r) => r['condition'] as String).toList();
  }

  // ---------------------------------------------------------------- THỐNG KÊ
  /// Tổng mật / phấn hoa / keo ong của từng tổ (có thể giới hạn theo khoảng ngày).
  Future<List<HiveTotal>> totalsPerHive({DateTime? from, DateTime? to}) async {
    final on = StringBuffer('v.hive_id = h.id');
    final args = <Object?>[];
    if (from != null) {
      on.write(' AND v.visit_date >= ?');
      args.add(_iso(from));
    }
    if (to != null) {
      on.write(' AND v.visit_date <= ?');
      args.add(_iso(to));
    }
    final rows = await (await db).rawQuery('''
      SELECT h.id, h.code, h.name,
             COUNT(v.id) AS visits,
             COALESCE(SUM(v.honey_g),0) AS honey,
             COALESCE(SUM(v.pollen_g),0) AS pollen,
             COALESCE(SUM(v.propolis_g),0) AS propolis
      FROM hives h LEFT JOIN visits v ON $on
      GROUP BY h.id ORDER BY h.code''', args);
    return rows.map(HiveTotal.fromMap).toList();
  }

  // ---------------------------------------------------------------- NHẮC LỊCH
  Future<List<Reminder>> reminders() async {
    final rows = await (await db).rawQuery('''
      SELECT r.*, h.name AS hive_name
      FROM reminders r JOIN hives h ON h.id = r.hive_id
      ORDER BY r.done, r.remind_at''');
    return rows.map(Reminder.fromMap).toList();
  }

  Map<String, Object?> _remMap(Reminder r) => {
        'hive_id': r.hiveId,
        'remind_at': r.remindAt.toIso8601String(),
        'note': r.note.trim(),
        'done': r.done ? 1 : 0,
      };

  Future<int> insertReminder(Reminder r) async =>
      (await db).insert('reminders', _remMap(r));

  Future<void> updateReminder(Reminder r) async => (await db)
      .update('reminders', _remMap(r), where: 'id = ?', whereArgs: [r.id]);

  Future<void> deleteReminder(int id) async =>
      (await db).delete('reminders', where: 'id = ?', whereArgs: [id]);

  /// Mã của mọi lịch nhắc thuộc một tổ (để hủy thông báo trước khi xóa tổ).
  Future<List<int>> reminderIdsOfHive(int hiveId) async {
    final rows = await (await db)
        .query('reminders', columns: ['id'], where: 'hive_id = ?', whereArgs: [hiveId]);
    return rows.map((r) => r['id'] as int).toList();
  }

  // ---------------------------------------------------------------- TỔNG QUAN
  Future<Map<String, double>> overview() async {
    final d = await db;
    Future<double> one(String sql) async =>
        ((await d.rawQuery(sql)).first.values.first as num?)?.toDouble() ?? 0;
    return {
      'hives': await one('SELECT COUNT(*) FROM hives'),
      'visits': await one('SELECT COUNT(*) FROM visits'),
      'honey': await one('SELECT COALESCE(SUM(honey_g),0) FROM visits'),
      'pollen': await one('SELECT COALESCE(SUM(pollen_g),0) FROM visits'),
      'propolis': await one('SELECT COALESCE(SUM(propolis_g),0) FROM visits'),
      'pending': await one(
          "SELECT COUNT(*) FROM reminders WHERE done = 0 AND remind_at >= '${DateTime.now().toIso8601String()}'"),
    };
  }

  static String _iso(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
}
