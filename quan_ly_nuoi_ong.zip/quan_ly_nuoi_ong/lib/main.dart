import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'screens/home_screen.dart';
import 'screens/login_screen.dart';
import 'services/notification_service.dart';
import 'services/session.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await NotificationService.init();
    await NotificationService.rescheduleAll();
  } catch (_) {
    // Thông báo lỗi không được làm app không mở được.
  }
  final loggedIn = await Session.restore();
  runApp(BeeApp(loggedIn: loggedIn));
}

class BeeApp extends StatelessWidget {
  final bool loggedIn;
  const BeeApp({super.key, required this.loggedIn});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quản lý nuôi ong',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      locale: const Locale('vi'),
      supportedLocales: const [Locale('vi'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: loggedIn ? const HomeScreen() : const LoginScreen(),
    );
  }
}
