import 'package:shared_preferences/shared_preferences.dart';

import '../db/app_database.dart';
import '../models/models.dart';

/// Phiên đăng nhập hiện tại. "Ghi nhớ đăng nhập" lưu tên đăng nhập vào
/// SharedPreferences để lần sau mở app vào thẳng màn hình chính.
class Session {
  Session._();

  static AppUser? current;
  static const _kUser = 'session_user';
  static const _kLast = 'last_username';

  /// Thử khôi phục phiên đã ghi nhớ. Trả về true nếu còn đăng nhập.
  static Future<bool> restore() async {
    try {
      final sp = await SharedPreferences.getInstance();
      final name = sp.getString(_kUser);
      if (name == null) return false;
      final u = await AppDatabase.instance.userByName(name);
      current = u;
      return u != null;
    } catch (_) {
      return false;
    }
  }

  static Future<String> lastUsername() async {
    try {
      final sp = await SharedPreferences.getInstance();
      return sp.getString(_kLast) ?? '';
    } catch (_) {
      return '';
    }
  }

  static Future<void> signIn(AppUser u, {required bool remember}) async {
    current = u;
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setString(_kLast, u.username);
      if (remember) {
        await sp.setString(_kUser, u.username);
      } else {
        await sp.remove(_kUser);
      }
    } catch (_) {}
  }

  static Future<void> signOut() async {
    current = null;
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.remove(_kUser);
    } catch (_) {}
  }
}
