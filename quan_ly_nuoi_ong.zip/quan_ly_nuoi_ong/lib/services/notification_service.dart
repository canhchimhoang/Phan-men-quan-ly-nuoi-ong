import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import '../db/app_database.dart';

/// Thông báo nhắc lịch thăm tổ ong (lên lịch bằng AlarmManager nên vẫn nhắc
/// khi đã đóng ứng dụng).
class NotificationService {
  NotificationService._();

  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static const NotificationDetails _details = NotificationDetails(
    android: AndroidNotificationDetails(
      'hive_reminders',
      'Nhắc lịch thăm tổ ong',
      channelDescription: 'Thông báo nhắc đến giờ thăm tổ ong đã lên lịch',
      importance: Importance.max,
      priority: Priority.high,
    ),
    iOS: DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    ),
  );

  static Future<void> init() async {
    if (_ready) return;
    tzdata.initializeTimeZones();
    try {
      tz.setLocalLocation(tz.getLocation('Asia/Ho_Chi_Minh'));
    } catch (_) {}
    const settings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(
        requestAlertPermission: false,
        requestBadgePermission: false,
        requestSoundPermission: false,
      ),
    );
    await _plugin.initialize(settings);
    _ready = true;
  }

  /// Xin quyền hiển thị thông báo (Android 13+, iOS). Trả về true nếu được cấp.
  static Future<bool> requestPermissions() async {
    await init();
    var granted = true;
    final android = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    if (android != null) {
      granted = (await android.requestNotificationsPermission()) ?? true;
      try {
        await android.requestExactAlarmsPermission();
      } catch (_) {}
    }
    final ios = _plugin.resolvePlatformSpecificImplementation<
        IOSFlutterLocalNotificationsPlugin>();
    if (ios != null) {
      granted = (await ios.requestPermissions(
              alert: true, badge: true, sound: true)) ??
          false;
    }
    return granted;
  }

  /// Đặt thông báo vào đúng [when]. Bỏ qua nếu thời điểm đã qua.
  static Future<void> schedule({
    required int id,
    required String title,
    required String body,
    required DateTime when,
  }) async {
    await init();
    if (!when.isAfter(DateTime.now())) return;
    final at = tz.TZDateTime.from(when, tz.local);

    Future<void> go(AndroidScheduleMode mode) => _plugin.zonedSchedule(
          id,
          title,
          body,
          at,
          _details,
          androidScheduleMode: mode,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
        );

    try {
      await go(AndroidScheduleMode.exactAllowWhileIdle);
    } catch (_) {
      // Chưa được cấp quyền báo thức chính xác -> dùng chế độ gần đúng giờ.
      await go(AndroidScheduleMode.inexactAllowWhileIdle);
    }
  }

  static Future<void> cancel(int id) async {
    await init();
    await _plugin.cancel(id);
  }

  /// Gửi một thông báo ngay lập tức để thử.
  static Future<void> showTest() async {
    await init();
    await _plugin.show(
      0,
      'Thử thông báo 🐝',
      'Thông báo nhắc thăm tổ ong đang hoạt động tốt!',
      _details,
    );
  }

  /// Đặt lại toàn bộ thông báo từ CSDL (gọi mỗi lần mở ứng dụng).
  static Future<void> rescheduleAll() async {
    await init();
    final list = await AppDatabase.instance.reminders();
    for (final r in list) {
      if (r.done || r.id == null) continue;
      await schedule(
        id: r.id!,
        title: 'Đến giờ thăm ${r.hiveName}',
        body: r.note.isEmpty ? 'Bạn có lịch thăm tổ ong hôm nay.' : r.note,
        when: r.remindAt,
      );
    }
  }
}
