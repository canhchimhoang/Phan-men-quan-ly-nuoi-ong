/// Các lớp dữ liệu, ánh xạ với các bảng SQLite.

double _d(Object? v) => v == null ? 0 : (v as num).toDouble();

class AppUser {
  final int? id;
  final String username;
  final String fullName;
  final String question;

  AppUser({
    this.id,
    required this.username,
    required this.fullName,
    this.question = '',
  });

  factory AppUser.fromMap(Map<String, Object?> m) => AppUser(
        id: m['id'] as int?,
        username: m['username'] as String,
        fullName: (m['full_name'] as String?) ?? '',
        question: (m['question'] as String?) ?? '',
      );
}

/// Danh mục "Vị trí của tổ ong".
class HiveLocation {
  final int? id;
  final String name;
  final int hiveCount; // số tổ đang đặt ở vị trí này

  HiveLocation({this.id, required this.name, this.hiveCount = 0});

  factory HiveLocation.fromMap(Map<String, Object?> m) => HiveLocation(
        id: m['id'] as int?,
        name: m['name'] as String,
        hiveCount: (m['hive_count'] as int?) ?? 0,
      );
}

/// Bảng "Thông tin về tổ ong".
class Hive {
  final int? id;
  final String code; // Mã tổ ong: ong_0001
  final String name; // Tên tổ ong
  final int? locationId;
  final String locationName; // chỉ để hiển thị (JOIN)
  final String characteristics; // Đặc điểm của tổ ong
  final DateTime createdDate; // Ngày tạo tổ ong

  Hive({
    this.id,
    required this.code,
    required this.name,
    this.locationId,
    this.locationName = '',
    this.characteristics = '',
    required this.createdDate,
  });

  factory Hive.fromMap(Map<String, Object?> m) => Hive(
        id: m['id'] as int?,
        code: m['code'] as String,
        name: m['name'] as String,
        locationId: m['location_id'] as int?,
        locationName: (m['location_name'] as String?) ?? '',
        characteristics: (m['characteristics'] as String?) ?? '',
        createdDate: DateTime.parse(m['created_date'] as String),
      );
}

/// Bảng "Thông tin thăm tổ ong".
class Visit {
  final int? id;
  final int hiveId;
  final String hiveName; // JOIN
  final String hiveCode; // JOIN
  final int visitNo; // Lần thăm thứ
  final DateTime visitDate; // Ngày thăm
  final String condition; // Tình trạng của tổ ong
  final double honey; // gram
  final double pollen; // gram
  final double propolis; // gram (keo ong)
  final String splitStatus; // Tình trạng tách đàn

  Visit({
    this.id,
    required this.hiveId,
    this.hiveName = '',
    this.hiveCode = '',
    required this.visitNo,
    required this.visitDate,
    required this.condition,
    this.honey = 0,
    this.pollen = 0,
    this.propolis = 0,
    this.splitStatus = 'chưa',
  });

  factory Visit.fromMap(Map<String, Object?> m) => Visit(
        id: m['id'] as int?,
        hiveId: m['hive_id'] as int,
        hiveName: (m['hive_name'] as String?) ?? '',
        hiveCode: (m['hive_code'] as String?) ?? '',
        visitNo: m['visit_no'] as int,
        visitDate: DateTime.parse(m['visit_date'] as String),
        condition: (m['condition'] as String?) ?? '',
        honey: _d(m['honey_g']),
        pollen: _d(m['pollen_g']),
        propolis: _d(m['propolis_g']),
        splitStatus: (m['split_status'] as String?) ?? '',
      );
}

/// Lịch nhắc thăm tổ ong.
class Reminder {
  final int? id;
  final int hiveId;
  final String hiveName; // JOIN
  final DateTime remindAt;
  final String note;
  final bool done;

  Reminder({
    this.id,
    required this.hiveId,
    this.hiveName = '',
    required this.remindAt,
    this.note = '',
    this.done = false,
  });

  factory Reminder.fromMap(Map<String, Object?> m) => Reminder(
        id: m['id'] as int?,
        hiveId: m['hive_id'] as int,
        hiveName: (m['hive_name'] as String?) ?? '',
        remindAt: DateTime.parse(m['remind_at'] as String),
        note: (m['note'] as String?) ?? '',
        done: (m['done'] as int? ?? 0) == 1,
      );
}

/// Dòng thống kê tổng hợp theo tổ ong.
class HiveTotal {
  final int hiveId;
  final String code;
  final String name;
  final int visits;
  final double honey;
  final double pollen;
  final double propolis;

  HiveTotal({
    required this.hiveId,
    required this.code,
    required this.name,
    required this.visits,
    required this.honey,
    required this.pollen,
    required this.propolis,
  });

  factory HiveTotal.fromMap(Map<String, Object?> m) => HiveTotal(
        hiveId: m['id'] as int,
        code: m['code'] as String,
        name: m['name'] as String,
        visits: (m['visits'] as int?) ?? 0,
        honey: _d(m['honey']),
        pollen: _d(m['pollen']),
        propolis: _d(m['propolis']),
      );
}
